# Yasin UI customization - initial pass

Base: original AndreyPavlenko/Fermata source tree provided by the user.

## Changes in this pass
- Adjusted the Black theme palette to a deeper charcoal/black base.
- Added red accent colors for activated controls, theme accent and ripple feedback.
- Shifted secondary surfaces and borders toward dark metallic grey.
- Left Android Auto service classes, media playback code, IPTV/M3U module, and web/YouTube module unchanged.

## Verification status
- Edited XML files parse successfully.
- APK build was not verified in this environment: Android SDK is not configured, and Gradle 9.7.1 could not be downloaded because network access to services.gradle.org was unavailable.

## Important
This is an initial theme pass, not yet the full custom classic-radio home screen. No new functional radio controls were added in this pass. The classic radio player and favorites UI require additional UI implementation and binding to existing playback/favorites APIs, followed by a build and device test.
